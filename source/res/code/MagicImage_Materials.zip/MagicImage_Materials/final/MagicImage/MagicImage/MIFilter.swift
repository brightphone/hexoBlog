/// Copyright (c) 2021 Razeware LLC
///
/// Permission is hereby granted, free of charge, to any person obtaining a copy
/// of this software and associated documentation files (the "Software"), to deal
/// in the Software without restriction, including without limitation the rights
/// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
/// copies of the Software, and to permit persons to whom the Software is
/// furnished to do so, subject to the following conditions:
///
/// The above copyright notice and this permission notice shall be included in
/// all copies or substantial portions of the Software.
///
/// Notwithstanding the foregoing, you may not use, copy, modify, merge, publish,
/// distribute, sublicense, create a derivative work, and/or sell copies of the
/// Software in any work that is designed, intended, or marketed for pedagogical or
/// instructional purposes related to programming, coding, application development,
/// or information technology.  Permission for such use, copying, modification,
/// merger, publication, distribution, sublicensing, creation of derivative works,
/// or sale is expressly withheld.
///
/// This project and source code may use libraries or frameworks that are
/// released under various Open-Source licenses. Use of those libraries and
/// frameworks are governed by their own individual licenses.
///
/// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
/// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
/// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
/// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
/// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
/// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
/// THE SOFTWARE.

import CoreImage.CIFilterBuiltins
import Foundation

public protocol MIFilter: Equatable, Identifiable {
  var name: String { get }
  func apply(to miImage: MIImage) -> MIImage
}

// MARK: Basic Filters

public struct IdentityFilter: MIFilter {
  public var name = "Normal"
  public var id: String { self.name }

  public init() {}

  public func apply(to miImage: MIImage) -> MIImage {
    return miImage
  }
}

public struct Sepia: MIFilter {
  public var name = "Sepia"
  public var id: String { self.name }

  public init() {}

  public func apply(to miImage: MIImage) -> MIImage {
    let ciFilter = CIFilter.sepiaTone()
    ciFilter.inputImage = miImage
    ciFilter.intensity = 1

    // Create a CIImage from our filter
    guard let outputImage = ciFilter.outputImage else {
      return miImage
    }

    return outputImage
  }
}

public struct Olde: MIFilter {
  public var name = "Olde"
  public var id: String { self.name }

  public init() {}

  public func apply(to miImage: MIImage) -> MIImage {
    let ciFilter = CIFilter.sepiaTone()
    ciFilter.inputImage = miImage
    ciFilter.intensity = 0.75

    // Create a CIImage from our filter
    guard let outputImage = ciFilter.outputImage else {
      return miImage
    }

    return outputImage
  }
}

public struct Posterize: MIFilter {
  public var name = "Posterize"
  public var id: String { self.name }

  public init() {}

  public func apply(to miImage: MIImage) -> MIImage {
    let ciFilter = CIFilter.colorPosterize()
    ciFilter.inputImage = miImage
    ciFilter.levels = 10

    guard let outputImage = ciFilter.outputImage else {
      return miImage
    }

    return outputImage
  }
}

public struct Crystallize: MIFilter {
  public var name = "Crystallize"
  public var id: String { self.name }

  public init() {}

  public func apply(to miImage: MIImage) -> MIImage {
    let ciFilter = CIFilter.crystallize()
    ciFilter.inputImage = miImage
    ciFilter.radius = 50

    guard let outputImage = ciFilter.outputImage else {
      return miImage
    }

    return outputImage
  }
}

public struct HorizontalFlip: MIFilter {
  public var name = "Flip Horizontal"
  public var id: String { self.name }

  public init() {}

  public func apply(to miImage: MIImage) -> MIImage {
    return miImage.oriented(.upMirrored)
  }
}

// MARK: Complex Filters

public struct Compose<T: MIFilter, U: MIFilter>: MIFilter {
  public var name: String {
    return "Compose<\(type(of: first)), \(type(of: second))>"
  }
  public var id: String { self.name }

  let first: T
  let second: U

  public func apply(to miImage: MIImage) -> MIImage {
    return second.apply(to: first.apply(to: miImage))
  }
}

// MARK: Utility Functions

public func compose<T: MIFilter, U: MIFilter>(_ first: T, _ second: U) -> some MIFilter {
  Compose(first: first, second: second)
}

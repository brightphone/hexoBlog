/// Copyright (c) 2021 Razeware LLC
/// 
/// Permission is hereby granted, free of charge, to any person obtaining a copy
/// of this software and associated documentation files (the "Software"), to deal
/// in the Software without restriction, including without limitation the rights
/// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
/// copies of the Software, and to permit persons to whom the Software is
/// furnished to do so, subject to the following conditions:
/// 
/// The above copyright notice and this permission notice shall be included in
/// all copies or substantial portions of the Software.
/// 
/// Notwithstanding the foregoing, you may not use, copy, modify, merge, publish,
/// distribute, sublicense, create a derivative work, and/or sell copies of the
/// Software in any work that is designed, intended, or marketed for pedagogical or
/// instructional purposes related to programming, coding, application development,
/// or information technology.  Permission for such use, copying, modification,
/// merger, publication, distribution, sublicensing, creation of derivative works,
/// or sale is expressly withheld.
/// 
/// This project and source code may use libraries or frameworks that are
/// released under various Open-Source licenses. Use of those libraries and
/// frameworks are governed by their own individual licenses.
///
/// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
/// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
/// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
/// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
/// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
/// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
/// THE SOFTWARE.

import SwiftUI

import MagicImage

struct FiltergramView: View {
  @State private var image: Image?

  @State private var selectedFilter = AnyFilter(IdentityFilter())

  let filters: [AnyFilter]

  init() {
    let identity = IdentityFilter()
    let sepia = Sepia()
    let olde = Olde()
    let posterize = Posterize()
    let crystallize = Crystallize()
    let flipHorizontally = HorizontalFlip()

    filters = [
      identity.asAnyFilter(),
      sepia.asAnyFilter(),
      olde.asAnyFilter(),
      posterize.asAnyFilter(),
      AnyFilter(crystallize),
      AnyFilter(flipHorizontally)
    ]
  }

  var body: some View {
    VStack {
      Spacer()
      image?
        .resizable()
        .scaledToFit()
      Spacer()
      FilterBarView(
        selectedFilter: $selectedFilter,
        allFilters: filters)
    }
    .background(Color.black)
    .onAppear(perform: loadImage)
    .onChange(of: selectedFilter) { _ in loadImage() }
  }

  func loadImage() {
    guard let inputImage = UIImage(named: "Butterfly") else { return }

    let uiImage = inputImage.apply(selectedFilter)
    image = Image(uiImage: uiImage)
  }
}

#if DEBUG
struct FiltergramView_Previews: PreviewProvider {
  static var previews: some View {
    FiltergramView()
  }
}
#endif

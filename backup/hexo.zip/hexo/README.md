## [Brightphone](https://brightphone.github.io)
[![Build Status](https://travis-ci.org/brightphone/hexoBlog.svg?branch=master)](https://travis-ci.org/brightphone/hexoBlog)
